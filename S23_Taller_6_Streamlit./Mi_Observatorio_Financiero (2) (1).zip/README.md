# Radar de Inversiones – S23 Taller 6

# 

# 1\. Descripción del proyecto

# 

# Radar de Inversiones es una aplicación web desarrollada con Python y Streamlit para consultar, visualizar y analizar el comportamiento de diferentes activos financieros.

# 

# La herramienta permite comparar activos, observar sus precios históricos, calcular indicadores de rentabilidad y riesgo, y visualizar información mediante gráficos interactivos.

# 

# Este proyecto fue desarrollado con fines académicos para la asignatura Lenguajes de Programación de Ingeniería Financiera y de Negocios del ITM.

# 

# 2\. Fuente de datos

# 

# La aplicación utiliza Yahoo Finance mediante la biblioteca yfinance para consultar precios históricos ajustados de los activos financieros seleccionados.

# 

# También cuenta con un modo de datos simulados para realizar pruebas cuando no es posible acceder a Yahoo Finance. Estos datos son ficticios y no representan cotizaciones reales del mercado.

# 

# 3\. Tecnologías utilizadas

# 

# Python: lenguaje de programación.

# 

# Streamlit: creación de la aplicación web interactiva.

# 

# Pandas: organización y procesamiento de datos.

# 

# NumPy: operaciones matemáticas y generación de datos simulados.

# 

# yfinance: consulta de información financiera.

# 

# Plotly: elaboración de gráficos interactivos.

# 

# Pillow: creación de la imagen de encabezado.

# 

# 4\. Funcionalidades

# 

# Selección de activos financieros.

# 

# Configuración del período histórico.

# 

# Definición del capital inicial.

# 

# Comparación del comportamiento de los activos.

# 

# Visualización de medias móviles de 20 y 50 días.

# 

# Cálculo de rendimientos y volatilidad.

# 

# Estadística descriptiva.

# 

# Análisis de correlaciones.

# 

# Visualización de la curva de Drawdown.

# 

# Descarga de precios históricos en formato CSV.

# 

# 5\. Indicadores financieros

# 

# Rendimiento acumulado: mide la ganancia o pérdida porcentual del portafolio durante el período analizado.

# 

# Volatilidad anualizada: mide la variabilidad de los rendimientos y permite evaluar el riesgo.

# 

# Medias móviles: ayudan a identificar tendencias en los precios de los activos.

# 

# Correlación: mide la relación entre los movimientos de los rendimientos de diferentes activos.

# 

# Drawdown: identifica las caídas del portafolio respecto a sus máximos históricos.

# 

# El portafolio utiliza ponderaciones iguales para los activos seleccionados y rebalanceo diario.

# 

# 6\. Instalación y ejecución

# 

# Para ejecutar la aplicación localmente, se deben seguir estos pasos:

# 

# Instalar Python.

# 

# Descargar o clonar el repositorio.

# 

# Instalar las dependencias mediante el siguiente comando:

# 

# pip install -r requirements.txt

# 

# Ejecutar la aplicación:

# 

# streamlit run app.py

# 

# 7\. Consideraciones

# 

# Este proyecto tiene fines exclusivamente académicos. Los resultados se basan en información histórica y no garantizan rendimientos futuros.

# 

# El análisis no contempla costos de transacción, impuestos ni otros gastos asociados a la inversión.

# 

# 8\. Autor

# 

# Estudiante: Lina Paola Alarcón Arboleda

# 

# Institución: Instituto Tecnológico Metropolitano (ITM).

# 

# Asignatura: Lenguajes de Programación.

# 

# Actividad: S23 – Taller 6.

